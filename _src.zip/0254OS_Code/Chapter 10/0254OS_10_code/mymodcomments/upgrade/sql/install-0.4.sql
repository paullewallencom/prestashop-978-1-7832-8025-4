ALTER TABLE `PREFIX_mymod_comment`
ADD `id_shop` int(11) NOT NULL AFTER `id_mymod_comment`