function mymodcomments_reset(msg_confirm)
{
	return confirm(msg_confirm);
}