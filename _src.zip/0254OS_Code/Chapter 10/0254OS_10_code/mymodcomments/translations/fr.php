<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mymodcomments}prestashop>mymodcomments_1a890b5867eb94d83f1f3e8d89c90a2e'] = 'Mon module de commentaires produits';
$_MODULE['<{mymodcomments}prestashop>mymodcomments_e5da9bc6456a101ef97145c53f269a7a'] = 'Avec ce module, vos clients pourront noter et commenter vos produits.';
$_MODULE['<{mymodcomments}prestashop>displayproducttabcontent_b91c4e8b229a399a3bc911d352524a9b'] = 'Commentaires produits';
$_MODULE['<{mymodcomments}prestashop>displayproducttabcontent_17a6f1f9930d065f8ebe6289ced7ec18'] = 'Note :';
$_MODULE['<{mymodcomments}prestashop>displayproducttabcontent_0be8406951cdfda82f00f79328cf4efc'] = 'Commentaire';
$_MODULE['<{mymodcomments}prestashop>displayproducttabcontent_240f3031f25601fa128bd4e15f0a37de'] = 'Commentaire :';
$_MODULE['<{mymodcomments}prestashop>displayproducttabcontent_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_MODULE['<{mymodcomments}prestashop>getcontent_c888438d14855d7d96a2724ee9c306bd'] = 'Configuration mis à jour';
$_MODULE['<{mymodcomments}prestashop>getcontent_60cbc06230f539caccf52f62589db470'] = 'Configuration de Mon Module';
$_MODULE['<{mymodcomments}prestashop>getcontent_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{mymodcomments}prestashop>getcontent_758e016a08af42d88ed2a0ee3ce8e1a3'] = 'Activer les notes :';
$_MODULE['<{mymodcomments}prestashop>getcontent_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{mymodcomments}prestashop>getcontent_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{mymodcomments}prestashop>getcontent_e4abac67834473cf9b1bfc77db6193bc'] = 'Activer les commentaires :';
$_MODULE['<{mymodcomments}prestashop>getcontent_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
