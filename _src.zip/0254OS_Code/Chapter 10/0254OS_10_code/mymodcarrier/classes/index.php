<?php

header("Location: ../");
exit;
