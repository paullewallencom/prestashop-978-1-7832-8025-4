<?php

require_once('simple-api.php');
$api = new SimpleApi();
$api->run();